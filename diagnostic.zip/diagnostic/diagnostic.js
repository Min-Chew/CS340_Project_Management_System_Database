var express = require('express');
var mysql = require('./dbcon.js');

var app = express();
var handlebars = require('express-handlebars').create({defaultLayout:'main'});

app.engine('handlebars', handlebars.engine);
app.set('view engine', 'handlebars');
app.set('port', process.argv[2]);

app.use(express.static('public'));

app.get('/', function(req,res,next){
        var context = {};
        mysql.pool.query('SELECT p.ID, p.Name, p.Start_date, p.Anticipated_end_date, p.Budget, p.Client_id FROM Projects p', function(err, rows, fields){
                if(err){
                        next(err);
                        return;
                }
                context.results = JSON.stringify(rows);
                res.render('index', context);
        });
});

app.get('/insert',function(req,res,next){
    res.render('insert');
});
app.get('/update',function(req,res,next){
    res.render('update');
});
app.get('/addDepartment',function(req,res,next){
    res.render('addDepartment');
});
app.get('/updateDepartment',function(req,res,next){
    res.render('updateDepartment');
});
app.get('/addProgrammer',function(req,res,next){
    res.render('addProgrammer');
});
app.get('/updateProgrammer',function(req,res,next){
    res.render('updateProgrammer');
});

app.post('/insert',function(req,res){
        var values = [
                [req.body.name, req.body.startDate, req.body.endDate, req.body.budget, req.body.clientId]
        ];
        mysql.pool.query('INSERT INTO Projects (Name, Start_date, Anticipated_end_date, Budget, Client_id) VALUES ?', [values]);
});


app.use(function(req,res){
  res.status(404);
  res.render('404');
});

app.use(function(err, req, res, next){
  console.error(err.stack);
  res.status(500);
  res.render('500');
});

app.listen(app.get('port'), function(){
  console.log('Express started on http://localhost:' + app.get('port') + '; press Ctrl-C to terminate.');
});
