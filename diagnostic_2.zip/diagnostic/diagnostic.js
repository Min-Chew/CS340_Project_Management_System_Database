var express = require('express');
var mysql = require('./dbcon.js');
var bodyParser = require('body-parser');

var app = express();
var handlebars = require('express-handlebars').create({defaultLayout:'main'});

app.engine('handlebars', handlebars.engine);
app.set('view engine', 'handlebars');
app.use(bodyParser.json());
app.set('port', process.argv[2]);

app.use(express.static('public'));

app.get('/', function(req,res,next){
        var context = {};
        mysql.pool.query('SELECT p.ID, p.Name, p.Start_date, p.Anticipated_end_date, p.Budget, p.Client_id FROM Projects p', function(err, results, fields){
                if(err){
                        next(err);
                        return;
                }
                context.projects = results;
                res.render('index', context);
        });
});

app.get('/insert',function(req,res,next){
    res.render('insert');
});
app.get('/update',function(req,res,next){
    res.render('update');
});
app.get('/addDepartment',function(req,res,next){
        var context = {};
        var sql = "SELECT p.Name FROM Projects p";
        sql = mysql.pool.query(sql, function(error, results, fields){
                if(error){
                        console.log(JSON.stringify(error));
                        res.write(JSON.stringify(error));
                        res.end();
                }
                context.projects = results;
                res.render('addDepartment', context);
        });
});
app.get('/updateDepartment',function(req,res,next){
    res.render('updateDepartment');
});
app.get('/addProgrammer',function(req,res,next){
    res.render('addProgrammer');
});
app.get('/updateProgrammer',function(req,res,next){
    res.render('updateProgrammer');
});

app.post('/insert',function(req,res){
//        var mysql = req.app.get('mysql');
        var values = [req.body.name, req.body.startDate, req.body.endDate, req.body.budget, req.body.clientId];
        var sql = "INSERT INTO Projects (Name, Start_date, Anticipated_end_date, Budget, Client_id) VALUES (?,?,?,?,?)";
        sql = mysql.pool.query(sql, values, function(error, results, fields){
                if(error){
                        console.log(JSON.stringify(error));
                        res.write(JSON>stringify(error));
                        res.end();
                }
                // res.redirect('/addDepartment');
        });
});


app.use(function(req,res){
  res.status(404);
  res.render('404');
});

app.use(function(err, req, res, next){
  console.error(err.stack);
  res.status(500);
  res.render('500');
});

app.listen(app.get('port'), function(){
  console.log('Express started on http://localhost:' + app.get('port') + '; press Ctrl-C to terminate.');
});
